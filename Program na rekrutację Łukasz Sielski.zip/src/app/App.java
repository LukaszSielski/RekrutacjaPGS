package app;

public class App {

	public static void main(String[] args) {
		AppControl app = new AppControl();
		app.loop();
	}
}
