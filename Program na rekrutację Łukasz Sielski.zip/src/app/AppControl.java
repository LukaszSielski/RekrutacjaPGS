package app;

import java.util.NoSuchElementException;
import java.util.Scanner;
import shapes.*;

public class AppControl {

	Scanner sc;
	private Shape sh;
	private Triangle triangle;
	private Rectangle rectangle;

	public AppControl() {
		sc = new Scanner(System.in);
		triangle = new Triangle();
		rectangle = new Rectangle();
		setSh(null);
	}

	public void loop() {
		Option option = null;
		while (option != Option.EXIT) {
			try {
				printOptions();
				option = Option.createOption(sc.nextInt());
				switch (option) {
				case RECTANGLE:
					sh = rectangle;
					sh.askForParameters(sc);
					sh.calculatePerimeter();
					sh.calculateField();
					System.out.println(sh);
					break;
				case TRIANGLE:
					sh = triangle;
					sh.askForParameters(sc);
					sh.calculatePerimeter();
					sh.calculateField();
					System.out.println(sh);
					break;
				case EXIT:
					sc.close();
					break;
				}
			} catch (NoSuchElementException e) {
				System.err.println("PODANO NIEW�A�CIWE DANE!");
				sc.nextLine();
			}
		}
	}

	private void printOptions() {
		System.out.println("Dost�pne opcje:");
		for (Option o : Option.values()) {
			System.out.println(o);
		}
	}

	private void setSh(Shape sh) {
		this.sh = sh;
	}

	private enum Option {
		RECTANGLE(1, "Prostok�t"), TRIANGLE(2, "Tr�jk�t"), EXIT(3, "Wyj�cie");

		private int number;
		private String description;

		Option(int num, String desc) {
			setNumber(num);
			setDescription(desc);
		}

		@Override
		public String toString() {
			return getNumber() + " - " + getDescription();
		}

		public static Option createOption(int num) throws NoSuchElementException {
			Option option = null;
			try {
				option = Option.values()[num - 1];
			} catch (ArrayIndexOutOfBoundsException e) {
				throw new NoSuchElementException("BRAK WPISANEJ OPCJI!");
			}
			return option;
		}

		public int getNumber() {
			return number;
		}

		public void setNumber(int number) {
			this.number = number;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}
	}
}
