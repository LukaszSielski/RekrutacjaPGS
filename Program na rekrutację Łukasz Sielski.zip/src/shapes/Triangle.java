package shapes;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Triangle extends Shape {
	private double a;
	private double b;
	private double c;

	public Triangle() {
		super();
		setA(0);
		setB(0);
		setC(0);
	}

	@Override
	public void calculatePerimeter() {
		setPerimeter(getA() + getB() + getC());
	}

	@Override
	public void calculateField() {
		double pom1 = getA() + getB() + getC();
		double pom2 = getA() + getB() - getC();
		double pom3 = getA() - getB() + getC();
		double pom4 = -getA() + getB() + getC();
		double P = (Math.sqrt(pom1 * pom2 * pom3 * pom4)) / 4;
		setField(P);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Tr�jk�t o wymiarach :\na = ");
		sb.append(getA());
		sb.append("\nb = ");
		sb.append(getB());
		sb.append("\nc = ");
		sb.append(getC());
		sb.append("\nObw�d = ");
		sb.append(getPerimeter());
		sb.append("\nPole = ");
		sb.append(getField());
		return sb.toString();
	}

	@Override
	public void askForParameters(Scanner sc) {
		System.out.println("Wybrano tr�jk�t");
		boolean isTriangle = false;
		while (!isTriangle) {
			boolean error = true;
			while (error) {
				try {
					System.out.println("Podaj d�ugo�� boku a: ");
					double a = sc.nextDouble();
					if (a <= 0) {
						error = true;
						System.err.println("PODANO UJEMN� LUB ZEROW� D�UGO��");
					} else {
						setA(a);
						error = false;
					}
				} catch (InputMismatchException e) {
					System.err.println("Z�Y FORMAT LICZBY");
					sc.nextLine();
				}
			}

			error = true;
			while (error) {
				try {
					System.out.println("Podaj d�ugo�� boku b: ");
					double b = sc.nextDouble();
					if (b <= 0) {
						error = true;
						System.err.println("PODANO UJEMN� LUB ZEROW� D�UGO��");
					} else {
						setB(b);
						error = false;
					}
				} catch (InputMismatchException e) {
					System.err.println("Z�Y FORMAT LICZBY");
					sc.nextLine();
				}
			}

			error = true;
			while (error) {
				try {
					System.out.println("Podaj d�ugo�� boku c: ");
					double c = sc.nextDouble();
					if (c <= 0) {
						error = true;
						System.err.println("PODANO UJEMN� LUB ZEROW� D�UGO��");
					} else {
						setC(c);
						error = false;
					}
				} catch (InputMismatchException e) {
					System.err.println("Z�Y FORMAT LICZBY");
					sc.nextLine();
				}
			}

			if (isTriangle()) {
				isTriangle = true;
			} else {
				System.err.println("PROSTE O PODANYCH D�UGO�CIACH NIE TWORZ� TR�JK�TA");
				isTriangle = false;
			}
		}
	}

	private boolean isTriangle() {
		double a = getA();
		double b = getB();
		double c = getC();
		if ((a + b) > c && (a + c) > b && (b + c) > a) {
			return true;
		}
		return false;
	}

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	public double getC() {
		return c;
	}

	public void setC(double c) {
		this.c = c;
	}
}
