package shapes;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Rectangle extends Shape {
	private double a;
	private double b;

	public Rectangle() {
		super();
		setA(0);
		setB(0);
	}

	@Override
	public void askForParameters(Scanner sc) {
		System.out.println("Wybrano prostok�t");
		boolean error = true;
		while (error) {
			try {
				System.out.println("Podaj d�ugo�� boku a: ");
				double a = sc.nextDouble();
				if (a <= 0) {
					error = true;
					System.err.println("PODANO UJEMN� LUB ZEROW� D�UGO��");
				} else {
					error = false;
					setA(a);
				}
			} catch (InputMismatchException e) {
				System.err.println("PODAJ LICZB�");
				sc.nextLine();
			}
		}

		error = true;
		while (error) {
			try {
				System.out.print("Podaj d�ugo�� boku b: ");
				double b = sc.nextDouble();
				if (b <= 0) {
					error = true;
					System.err.println("PODANO UJEMN� LUB ZEROW� D�UGO��");
				} else {
					error = false;
					setB(b);
				}
			} catch (InputMismatchException e) {
				System.err.println("PODAJ LICZB�");
				sc.nextLine();
			}
		}
	}

	@Override
	public void calculatePerimeter() {
		setPerimeter(2 * getA() + 2 * getB());
	}

	@Override
	public void calculateField() {
		setField(a * b);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Prostok�t o wymiarach :\na = ");
		sb.append(getA());
		sb.append("\nb = ");
		sb.append(getB());
		sb.append("\nObw�d = ");
		sb.append(getPerimeter());
		sb.append("\nPole = ");
		sb.append(getField());
		return sb.toString();
	}

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

}
