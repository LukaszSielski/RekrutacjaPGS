package shapes;

import java.util.Scanner;

public abstract class Shape {
	private double perimeter;
	private double field;

	public Shape() {
		setField(0);
		setPerimeter(0);
	}

	public abstract void calculatePerimeter();

	public abstract void calculateField();

	public abstract void askForParameters(Scanner sc);

	public double getField() {
		return field;
	}

	public void setField(double field) {

		this.field = field;
	}

	public double getPerimeter() {
		return perimeter;
	}

	public void setPerimeter(double perimeter) {
		this.perimeter = perimeter;
	}
}